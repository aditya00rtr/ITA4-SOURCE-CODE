<html>
<body>

<form action="forminsert.php" >
Name: <input type="text" name="name"><br>
E-mail: <input type="email"name="email"><br>
<input type="submit">
</form>

</body>
</html>