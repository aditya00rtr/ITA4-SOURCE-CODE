<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = 'booking';

//create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// check connection 
if ($conn->connect_error){
    die("Connection failed:" . $conn->connect_error);
}
 
$sql = "CREATE TABLE Booktable (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date VARCHAR(20),
    hours INT(10),
    name VARCHAR(50),
    email VARCHAR(50),
    number INT(10))";


    if($conn->query($sql) === True) {
        echo "Table Created Sucessfully";
    }else{
        echo "Error Creating Table: " . $conn->error;
    }

    $conn->close();
    ?>
    