<?php
$servername = "localhost";
$username = "root";
$password = "";

//create connection
$conn = new mysqli($servername, $username, $password);

// check connection 
 if($conn->connect_error) {
     die("connection failed: " . $conn->connect_error);
 }

 $sql = "CREATE DATABASE booking";
 if(mysqli_query($conn, $sql)){
     echo "Database Connected Sucessfully";
 } else {
     echo "Error Creating Database: " . mysqli_error($conn);
 }

 mysqli_close($conn);;

?>