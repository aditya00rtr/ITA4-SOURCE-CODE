<?php
$servername = "localhost";
$username ="root";
$password="";
$dbname = "barkha";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$name=$_REQUEST['name'];
$email=$_REQUEST['email'];
$sql="insert into shaina values('$name','$email')";
if ($conn->query($sql) === TRUE) {
  echo "data inserted MyGuests created successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>