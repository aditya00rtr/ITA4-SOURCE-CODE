<?php
$name = $_POST['name'];
$visitor_name = $_POST['email'];
$mobile = $_POST['mobile'];
$query = $_POST['query'];

$email_name = '20bcs4945@cuchd.in';
$email_subject = 'New form submission';
$email_body = "user name: $name.\n".
              "user name: $visitor_email.\n".
              "mobile: $mobile.\n".
              "user query: $query.\n";

     $to = '20bcs4946@cuchd.in';
     $header = "from: $email_from \r\n";
     $header. = "Reply-to: $visitor_email\r\n";
     mail($to,$email_subject,$email_body,$header);
    
     header("Location: contact.html");
?>