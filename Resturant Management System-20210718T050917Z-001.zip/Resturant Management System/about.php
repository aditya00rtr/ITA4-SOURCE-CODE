<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barbeque Nation</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/all.min.css">
</head>
<body>
    <section class="sub-header">
     
      <nav>
        <a class="cen" href="index.html"> <img src="logo.png" alt="" ></a>
        <div class="nav-links" id="navLinks">
          <i class="fa fa-times" onclick="hideMenu()"></i>
        <ul>
            <li><a href="index.html">home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="menu.html">Menu</a></li>
            <li><a href="gallery.html">Gallery</a></li>
            <li><a href="contact.html">contact</a></li>
           <li> <a href="#"><input type="search" placeholder="search here">
                <span class="fa fa-search"></span></a></li>
            
        </ul>
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
    </nav>
    <h1>About Us</h1>
    </section>

    <section class="about-us">  
      <div class="row">  
         <div class="about-col">  
         <h1>Our approach<br> ALWAYS FRESH INGREDIENTS</h1>      
  <p>Here at Barbeque Nation we work with only the best food supliers like small family farms, insuring that we always have the best and always fresh ingredients. You’ll find a large variety of dishes made to satisfy any taste, from sea food, steaks, variety of natural soups, pasta, salads, finest deserts and vines...</p>     
           <a href="menu.html" class="hero-btn red-btn">Explore Now</a>  
              </div>   
             <div class="about-col">  
              <img src="about-us.jpg" alt=""> 
            </div>
        </div> 
     </section>

     <!----------------------- Booking Form------------------------------->
     <h2>BOOK YOUR TABLE NOW</h2>
     <section class = "banner">
       
      <div class = "card-container">
          <div class = "card-img">
              <img src="book.jpg" alt="">
          </div>

          <div class = "card-content">
              <h3>Reservation</h3>
              <form action="userinfo.php" method="POST">
                  <div class = "form-row">
                      <input type="date" value="date" name="date">
                      <select name = "hours">
                          <option value = "hour-select">Select Hour</option>
                          <option value = "10">10: 00</option>
                          <option value = "12">12: 00</option>
                          <option value = "14">14: 00</option>
                          <option value = "16">16: 00</option>
                          <option value = "18">18: 00</option>
                          <option value = "20">20: 00</option>
                          <option value = "22">22: 00</option>
                      </select>
                  </div>

                  <div class = "form-row">
                      <input type = "text" placeholder="Full Name" name="name">
                      <input type = "email" placeholder="E-mail" name="email">
                  </div>

                  <div class = "form-row">
                      <input type = "number" placeholder="How Many Persons?" min = "1" name="number">
                      <input type = "submit" value = "BOOK TABLE" name="submit">
                  </div>
              </form>
          </div>
      </div>
  </section>

    
            
            <!------------------Footer-------------->
            <section class="footer">
              <h4>About Us</h4>
              
              <div clas><img src="logo.png" alt="">
                <p> Madhya Marg, Block 2, Sector 26 <br> near Green Market, Chowk, Chandigarh, 160019</p>
                <i class="fas fa-phone"></i>
                <p class="reser">Reservation Number:6203411387 <br> Working Hours.</p>
                <p> MON- FRI: 08:00 AM - 10:00 PM <br> SAT - SUN: 10:00 AM - 11:00 PM</p>
              </div>

              <div class="icons">
                <i class="fab fa-facebook"></i>
                <i class="fab fa-twitter"></i>
                <i class="fab fa-instagram"></i>
                <i class="fab fa-linkedin"></i>
              </div>
              <p>Made With <i class="far fa-heart"></i> by Barbeque Nation</p>

            </section>
           
<!----------------------------------- JAVASCRIPT FOR NAVIGATION BAR ------------------------->
            <script>
            var navLinks = document.getElementById("navLinks")

              function showMenu(){
              navLinks.style.right = "0";
              }

              function hideMenu(){
                navLinks.style.right = "-200px";
              }
            
            </script>
            </body>
            </html>