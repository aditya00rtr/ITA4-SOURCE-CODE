<?php

error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "booking";
//create connection
$conn = new mysqli($servername, $username, $password, $dbname);

//check connection
if($conn->connect_error){
	die("connection failed : " . $conn->connect_error);
}

$id = $_POST['id'];
$date = $_POST['date'];
$hours = $_POST['hours'];
$name = $_POST['name'];
$email = $_POST['email'];
$number = $_POST['number'];

$sql ="insert into booktable values('$id', '$date', '$hours', '$name', '$email', '$number')";

if($conn->query($sql) === TRUE){
	echo "BOOKING SUCCESSFUL";
} 
else{
	echo "Error creating table : " . $conn->error;
}

$conn->close();
?>