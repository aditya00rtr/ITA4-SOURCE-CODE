<?php
session_start();

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Reader's Paradise</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="./style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Oswald&display=swap" rel="stylesheet">
</head>

<body>
    <nav class="zoneBoi">
        <ul class="main-nav">
            <li class='pushBoi'><a href="./about.html" style='padding: 10px; color:white; text-decoration:none;'>About</a>
            </li>
            <li class='pushBoi'><a href="#collectionBoi" style='color: white; text-decoration:none;'>Our Collection</a>
            </li>
            <li>
                <a href='./welcome.php'><img class='pushBoiImg' src='./img/Screenshot 2021-06-30 at 17-12-33 Logo Maker Used By 2 3 Million Startups.png' alt=''>
                </a>
            </li>
            </li>
            <li class='pushBoi'><a href='#footer' style='color: white; text-decoration:none;'>Contact Us</a>
            </li>
            <li class="pushBoi"><a href="logout.php" style='color: white; text-decoration:none;'>Sign Out</a></li>
        </ul>
    </nav>
    <div class="container boiboi">
        <div class="slideshow-container">
            <div class="mySlides fade">
                <img class='cover' src="https://images.unsplash.com/photo-1532294220147-279399e4e00f?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80 ">
            </div>

            <div class=" mySlides fade">
                <img class='cover' src="https://images.unsplash.com/photo-1465929639680-64ee080eb3ed?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80">
            </div>

            <div class=" mySlides fade">
                <img class='cover' src="https://images.unsplash.com/photo-1491841651911-c44c30c34548?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1050&q=80" ">
			</div>
		</div>
				<div class='whiteBold containerBaby animate__animated animate__backInDown'>
					<h1 style=" font-family: 'Josefin Sans' ; font-size: 3rem;">Welcome to Reader's Paradise, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b> !</h1>
                <h3 style=" font-family: 'Dancing Script'; font-size: 3rem;">Wiser Everyday</h3>
            </div>
        </div>
        <br>
        <h1 style=" margin: 0 auto; font-family: Josefin Sans; font-size: 6em; color: white" id="collectionBoi">Our Collection</h1>
        <div class="grid-wrapper" id="grid">

            <div class="box zoneBoi" data-tilt data-tilt-scale='1.1'>
                <img src="https://harpercollins.co.in/PowerPoint_jpg/9780008226671.jpg">
                <div class="boiboi" style="font-size: 0.6em">
                    <p>
                        Agatha Christie's most famous murder mystery, reissued with a new cover to tie in with
                        the
                        hugely
                        anticipated 2017 film adaptation. Just after midnight, a snowdrift stops the Orient
                        Express
                        in
                        its
                        tracks. The luxurious train is surprisingly full for the time of the year, but by the
                        morning it
                        is
                        one
                        passenger fewer. An American tycoon lies dead in his compartment, stabbed a dozen times,
                        his
                        door
                        locked
                        from the inside. Isolated and with a killer in their midst, detective Hercule Poirot
                        must
                        identify
                        the
                        murderer - in case he or she decides to strike again.
                    </p>
                    <a class="buttonCustom" href="https://www.flipkart.com/murder-orient-express/p/itmfc8qyac6yvx7d?pid=9780008226671&lid=LSTBOK9780008226671DGUHOF&marketplace=FLIPKART&q=murder+on+the+orient+express&store=bks&srno=s_1_2&otracker=AS_QueryStore_HistoryAutoSuggest_1_6_na_na_na&otracker1=AS_QueryStore_HistoryAutoSuggest_1_6_na_na_na&fm=SEARCH&iid=09978b68-a9d9-4463-9624-f5653607035e.9780008226671.SEARCH&ppt=pp&ppn=pp&ssid=bqpsu5300hg44ge81624979783656&qH=73d4e350981db6bc" target="_blank">Buy
                        Now</a>
                </div>
            </div>
            <div class="box zoneBoi" data-tilt data-tilt-scale='1.1'>
                <img src="https://rukminim1.flixcart.com/image/832/832/kq2o2vk0/regionalbooks/c/h/z/the-kite-runner-english-paperback-hosseini-khaled-original-imag466yfjfzby2y.jpeg">
                <div class='boiboi' style="font-size: 0.6em">
                    <p>
                        Afghanistan, 1975: Twelve-year-old Amir is desperate to win the local kite-fighting
                        tournament
                        and
                        his
                        loyal friend Hassan promises to help him. But neither of the boys can foresee what will
                        happen
                        to
                        Hassan
                        that afternoon, an event that is to shatter their lives. After the Russians invade and
                        the
                        family is
                        forced to flee to America, Amir realises that one day he must return to Afghanistan
                        under
                        Taliban
                        rule
                        to find the one thing that his new world cannot grant him: redemption.
                    </p>
                    <a class="buttonCustom" href="https://www.flipkart.com/kite-runner-english-paperback-hosseini-khaled/p/itmde634550e0e2f?pid=RBKG466YBZQDYYD3&lid=LSTRBKG466YBZQDYYD3LPENVY&marketplace=FLIPKART&q=the+kite+runner&store=bks&srno=s_1_2&otracker=AS_QueryStore_OrganicAutoSuggest_1_8_na_na_ps&otracker1=AS_QueryStore_OrganicAutoSuggest_1_8_na_na_ps&fm=SEARCH&iid=716cb69e-fec7-4639-8132-cff316f3d029.RBKG466YBZQDYYD3.SEARCH&ppt=pp&ppn=pp&ssid=7my41igbktpope681624979822441&qH=ace34b0faf89264a" target="_blank">Buy
                        Now</a>
                </div>
            </div>
            <div class="box zoneBoi" data-tilt data-tilt-scale='1.1'>
                <img src="https://rukminim1.flixcart.com/image/832/832/k7nnrm80/book/6/3/7/the-mysterious-affair-at-styles-original-imafpuffw7vbnsgq.jpeg">
                <div class='boiboi' style="font-size: 0.56em">
                    <p>
                        Marking exactly 100 years since the publication of Agatha Christie's first novel, this
                        new
                        edition includes a previously deleted chapter and a newly discovered essay, 'Drugs and
                        Detective Stories', in which Agatha Christie reminisces about the inspiration for
                        Poirot's
                        first case. 'Beware! Peril to the detective who says: "It is so small - it does not
                        matter..." Everything matters.' After the Great War, life can never be the same again.
                        Wounds need healing, and the horror of violent death banished into memory. Captain
                        Arthur
                        Hastings is invited to the rolling country estate of Styles to recuperate from injuries
                        sustained at the Front. It is the last place he expects to encounter murder.
                    </p>
                    <a class="buttonCustom" href="https://www.flipkart.com/mysterious-affair-styles/p/itmfbrtfgjc3byxw?pid=9780008400637&lid=LSTBOK9780008400637GZREU8&marketplace=FLIPKART&q=the+mysterious+affair+at+styles&store=bks&srno=s_1_3&otracker=AS_QueryStore_OrganicAutoSuggest_1_14_na_na_ps&otracker1=AS_QueryStore_OrganicAutoSuggest_1_14_na_na_ps&fm=SEARCH&iid=d7518551-48c9-4a38-bd7f-7fbad3f0f4a7.9780008400637.SEARCH&ppt=pp&ppn=pp&ssid=qi182ukt3gnu2bcw1624979849108&qH=eecd3187b69ff320" target="_blank">Buy
                        Now</a>
                </div>
            </div>
            <div class="box zoneBoi" data-tilt data-tilt-scale='1.1'>
                <img src="https://rukminim1.flixcart.com/image/832/832/kjym9ow0/book/v/j/e/and-then-there-were-none-original-imafze8vkm2hycyp.jpeg">
                <div class='boiboi' style="font-size: 0.6em">
                    <p> The World's Bestselling Mystery

                        "Ten . . ."
                        Ten strangers are lured to an isolated island mansion off the Devon coast by a
                        mysterious
                        "U. N. Owen."

                        "Nine . . ."
                        At dinner a recorded message accuses each of them in turn of having a guilty secret, and
                        by
                        the end of the night one of the guests is dead.

                        "Eight . . ."
                        Stranded by a violent storm, and haunted by a nursery rhyme counting down one by one . .
                        .
                        as one by one . . . they begin to die.

                        "Seven . . ."
                        Which among them is the killer and will any of them survive?
                    </p>
                    <a class="buttonCustom" href="https://www.flipkart.com/then-there-were-none/p/itmfc3mztkffqfkb?pid=9780008123208&lid=LSTBOK9780008123208RCQG0O&marketplace=FLIPKART&q=and+then+there+were+none&store=bks&srno=s_1_1&otracker=AS_QueryStore_OrganicAutoSuggest_1_19_na_na_ps&otracker1=AS_QueryStore_OrganicAutoSuggest_1_19_na_na_ps&fm=SEARCH&iid=d85025e0-a177-449e-83d1-77d43663958a.9780008123208.SEARCH&ppt=pp&ppn=pp&ssid=ppo91bf0yiskupds1624979874219&qH=66e769d762caf07d" target="_blank">Buy
                        Now</a>
                </div>
            </div>
            <div class="box zoneBoi" data-tilt data-tilt-scale='1.1'>
                <img src="https://rukminim1.flixcart.com/image/832/832/jph83gw0/book/0/4/4/the-hobbit-original-imafbpg7zcu7gwkh.jpeg">
                <div class='boiboi' style="font-size: 0.6em">
                    <p>
                        The complete story of Bilbo Baggins' adventures in Middle-earth as shown in the film
                        trilogy, with a striking cover image from Peter Jackson's film adaptation and drawings
                        and
                        maps by J.R.R. Tolkien. Bilbo Baggins is a hobbit who enjoys a comfortable, unambitious
                        life, rarely travelling further than the pantry of his hobbit-hole in Bag End. But his
                        contentment is disturbed when the wizard, Gandalf, and a company of thirteen dwarves
                        arrive
                        on his doorstep one day to whisk him away on an unexpected journey 'there and back
                        again'.
                    </p>
                    <a class="buttonCustom" href="https://www.flipkart.com/the-hobbit/p/itmfbphp3gqhcfhv?pid=9780008118044&lid=LSTBOK97800081180447XOU3B&marketplace=FLIPKART&q=hobbit&store=search.flipkart.com&srno=s_1_1&otracker=search&otracker1=search&fm=SEARCH&iid=a7c52f46-f03e-489d-bb8a-fb21111ef8e4.9780008118044.SEARCH&ppt=pp&ppn=pp&ssid=1die9ukeeczmiy9s1624979893502&qH=7baa6d93380e30bd" target="_blank">Buy
                        Now</a>
                </div>
            </div>
            <div class="box zoneBoi" data-tilt data-tilt-scale='1.1'>
                <img src="https://rukminim1.flixcart.com/image/832/832/book/1/3/7/the-hungry-tide-original-imaepx6haxednaht.jpeg">
                <div class='boiboi' style="font-size: 0.6em">
                    <p>
                        The Hungry Tide is set in the enormous and exotic Sundarbans in West Bengal. It is an
                        archipelago in the Bay of Bengal where the dwellers live in a constant fear of the
                        man-eating Royal Bengal Tigers and the erratic drowning tides. An impetuous Indian-born
                        American marine biologist named Piyali Roy comes to Sudarbans to study an unusual
                        species of
                        dolphins. But her expedition becomes a disaster from the very start, when she is tossed
                        from
                        a boat into the crocodile-infested water. Piyali is saved by Fokir, who is a young and
                        uneducated fisherman.
                    </p>
                    <a class="buttonCustom" href="https://www.flipkart.com/the-hungry-tide/p/itmfbz6bcxheb9wy?pid=9788172236137&lid=LSTBOK97881722361373H7HRK&marketplace=FLIPKART&q=the+hungry+tide&store=bks&spotlightTagId=BestvalueId_bks&srno=s_1_1&otracker=search&otracker1=search&fm=SEARCH&iid=3f17d9ca-2e35-4300-b60d-6aa0ab394a6a.9788172236137.SEARCH&ppt=sp&ppn=sp&ssid=zagg6pqyi80khg5c1624979913512&qH=852b8651cb5d9276" target="_blank">Buy
                        Now</a>
                </div>
            </div>
            <div class="box zoneBoi" data-tilt data-tilt-scale='1.1'>
                <img src="https://rukminim1.flixcart.com/image/832/832/k2nmaa80/book/4/7/8/turning-points-a-journey-through-challanges-original-imafhyg2gtwehjvm.jpeg?q=70">
                <div class='boiboi' style="font-size: 0.6em">
                    <p> This book, Turning Points: A Journey Through Challenges, takes up the story from when
                        A.P.J
                        Abdul Kalam became the President of India. It covers his acceptance of the post of the
                        President of India, his term in office, his efforts to make his term meaningful, and the
                        challenges he faced.

                        His term from 2002 to 2007 was an eventful one. The President of India is just a titular
                        head with minimal powers. But, the office is one of great influence and Kalam used it to
                        best effect. He got the government and the public to focus on issues that were relevant
                        to
                        the country's all round growth.</p>
                    <a class="buttonCustom" href="https://www.flipkart.com/turning-points-journey-through-challenges/p/itm8d2d97812d1b0?pid=9789350293478&lid=LSTBOK9789350293478WEIKWO&marketplace=FLIPKART&q=turning+point+by+apj+abdul+kalam&store=bks&srno=s_1_1&otracker=AS_QueryStore_OrganicAutoSuggest_2_6_na_na_ps&otracker1=AS_QueryStore_OrganicAutoSuggest_2_6_na_na_ps&fm=SEARCH&iid=deeb4575-cd08-4826-851f-502360325e67.9789350293478.SEARCH&ppt=pp&ppn=pp&ssid=u1a3qn0o6ipc85xc1624979944408&qH=f59ddb24ecd06d7a" target="_blank">Buy
                        Now</a>
                </div>
            </div>
            <div class="box zoneBoi" data-tilt data-tilt-scale='1.1'>
                <img src="https://rukminim1.flixcart.com/image/832/832/kjbr8280-0/book/2/e/h/poirot-death-on-the-nile-original-imafyxhgbr2mbq5z.jpeg">
                <div class='boiboi' style="font-size: 0.6em">
                    <p>Agatha Christie's most exotic murder mystery, reissued with a striking new cover designed
                        to
                        appeal to the latest generation of Agatha Christie fans and book lovers. The
                        tranquillity of
                        a cruise along the Nile is shattered by the discovery that Linnet Ridgeway has been shot
                        through the head. She was young, stylish and beautiful, a girl who had everything -
                        until
                        she lost her life. Hercule Poirot recalls an earlier outburst by a fellow passenger:
                        'I'd
                        like to put my dear little pistol against her head and just press the trigger.' Yet in
                        this
                        exotic setting' nothing is ever quite what it seems...</p>
                    <a class="buttonCustom" href="https://www.flipkart.com/death-on-the-nile/p/itmfc4vekhruaqwf?pid=9780007527557&lid=LSTBOK9780007527557H3CL0W&marketplace=FLIPKART&q=death+on+nile&store=bks&spotlightTagId=BestvalueId_bks&srno=s_1_2&otracker=AS_QueryStore_OrganicAutoSuggest_1_11_na_na_ps&otracker1=AS_QueryStore_OrganicAutoSuggest_1_11_na_na_ps&fm=SEARCH&iid=7f779a2a-3983-48e6-8d33-9874093fa459.9780007527557.SEARCH&ppt=sp&ppn=sp&ssid=iitx2u7ftilzbgn41624980024527&qH=0e8512f4440266cd" target="_blank">Buy
                        Now</a>
                </div>
            </div>
            <div class="box zoneBoi" data-tilt data-tilt-scale='1.1'>
                <img src="https://rukminim1.flixcart.com/image/832/832/j0tvngw0/book/5/2/8/looking-for-alaska-original-imaesjhjcf7dcqcu.jpeg">
                <div class='boiboi' style="font-size: 0.6em">
                    <p>When Miles Halter leaves his home for boarding school, he expects that he’ll find a
                        change
                        from the sedentary life he grew tired of. He takes the words of Francois Rabelais’ “the
                        Great Perhaps” to heart, as well as the words of other great thinkers, and hopes to find
                        something that will change his life. He has no idea how much of that change is about to
                        come
                        from a girl he is about to meet at Culver Creek. Alaska is a sprightly young girl,
                        fascinating and smart. She draws him into her life and sets him on the course to finding
                        Rabelais’ goal.</p>
                    <a class="buttonCustom" href="https://www.flipkart.com/looking-for-alaska/p/itmf3dpuprxeu8b8?pid=9780007523528&lid=LSTBOK9780007523528RJUOSE&marketplace=FLIPKART&q=looking+for+alaska&store=bks&srno=s_1_6&otracker=AS_QueryStore_OrganicAutoSuggest_1_6_na_na_ps&otracker1=AS_QueryStore_OrganicAutoSuggest_1_6_na_na_ps&fm=SEARCH&iid=a24fc72c-b6c3-4cf4-b403-a8934b9836c4.9780007523528.SEARCH&ppt=hp&ppn=homepage&ssid=kz0k9l9mtp7z6l8g1624980269724&qH=180b530f6150b3b4" target="_blank">Buy
                        Now</a>
                </div>
            </div>
            <div class="box zoneBoi" data-tilt data-tilt-scale='1.1'>
                <img src="https://rukminim1.flixcart.com/image/832/832/kit6hzk0-0/book/i/x/s/a-column-of-fire-original-imafyg53ztbctjvb.jpeg?q=70">
                <div class='boiboi' style="font-size: 0.6em">
                    <p>A WORLD IN TURMOIL 1558, and Europe is in revolt as religious hatred sweeps the
                        continent.
                        Elizabeth Tudor has ascended to the throne but she is not safe in this dangerous new
                        world.
                        There are many who would see her removed, not least Mary Queens of Scots, who lies in
                        wait
                        in Paris. A NEW ORDER Elizabeth determines to set up a new secret service: a group of
                        resourceful spies and courageous agents entrusted to keep her safe and in power. As she
                        searches for those who will make the difference, one man stands out. A MAN WHO WOULD DIE
                        FOR
                        HIS QUEEN For Ned Willard the opportunity to serve his queen is God-sent.</p>
                    <a class="buttonCustom" href=https://www.flipkart.com/a-column-of-fire/p/itmf4y92gwxypfyq?pid=9781447278771&lid=LSTBOK9781447278771RIHIAV&marketplace=FLIPKART&q=ken+follett&store=bks&srno=s_1_5&otracker=AS_QueryStore_OrganicAutoSuggest_1_8_sc_na_ps&otracker1=AS_QueryStore_OrganicAutoSuggest_1_8_sc_na_ps&fm=SEARCH&iid=861825d1-c91b-44bc-b8fc-9c0fbc1bb751.9781447278771.SEARCH&ppt=pp&ppn=pp&ssid=mdgij6jya57j9hj41624980369232&qH=cb77216a2cb2baeb" target="_blank">Buy
                        Now</a>
                </div>
            </div>
            <div class="box zoneBoi" data-tilt data-tilt-scale='1.1'>
                <img src="https://rukminim1.flixcart.com/image/832/832/kjhgzgw0-0/book/m/m/u/alchemist-original-imafzfhzefg8etxh.jpeg?q=70">
                <div class='boiboi' style="font-size: 0.6em">
                    <p>Santiago, an Andalusian shepherd boy, looks to travel the world in the quest to find a
                        worldly treasure, unlike any others. Santiago’s quest takes him to the magical desert of
                        Egypt, where he meets the alchemist. Is the alchemist what Santiago was looking for, or
                        is
                        he there to stop Santiago from fulfilling his quest? Well, you’ll have to read The
                        Alchemist
                        to find out. </p>
                    <a class="buttonCustom" href="https://www.flipkart.com/alchemist/p/itmfc9jxsc7dckfm?pid=9788172234980&lid=LSTBOK9788172234980YN61C7&marketplace=FLIPKART&q=alchemist&store=bks&srno=s_1_1&otracker=search&otracker1=search&fm=SEARCH&iid=f46d7789-f5b9-414b-aadf-96df4ba05317.9788172234980.SEARCH&ppt=pp&ppn=pp&ssid=rheso4ftohd8zxfk1624980526164&qH=132b133aafe31bcf" target="_blank">Buy
                        Now</a>
                </div>
            </div>
            <div class="box zoneBoi" data-tilt data-tilt-scale='1.1'>
                <img src="https://rukminim1.flixcart.com/image/832/832/kjx6tu80/book/8/h/r/the-power-of-your-subconscious-mind-original-imafzdzkyhbfkhd2.jpeg?q=70">
                <div class='boiboi' style="font-size: 0.6em">
                    <p> This book is designed to help you improve your
                        relationships, health, and also to give you an internal strength that makes every hurdle
                        look small. The book explains how by understanding and learning to control
                        our subconscious mind, we can welcome a world of prosperity, happiness and success. This
                        book will act as a guide and help you understand the depth of your subconscious, get rid
                        of
                        fears and attract what you desire simply by changing your beliefs. Having sold millions
                        of
                        copies, this book and its ideas have changed the lives of many all over the world.</p>
                    <a class="buttonCustom" href="https://www.flipkart.com/power-your-subconscious-mind/p/itmfawz5jdrcvuba?pid=9788194790839&lid=LSTBOK9788194790839NHDZ9I&marketplace=FLIPKART&q=the+power+of+your+subconscious+mind&store=bks&srno=s_1_4&otracker=AS_QueryStore_OrganicAutoSuggest_1_8_na_na_ps&otracker1=AS_QueryStore_OrganicAutoSuggest_1_8_na_na_ps&fm=SEARCH&iid=8de2f17e-926d-492c-b31b-ecda4acaf530.9788194790839.SEARCH&ppt=pp&ppn=pp&ssid=xftqhqxe88xas6ww1624980600141&qH=f8efce164dbe553d" target="_blank">Buy
                        Now</a>
                </div>
            </div>
        </div>
        <footer id="footer">
            <a href="#"><img src="./img/Screenshot 2021-06-30 at 17-12-33 Logo Maker Used By 2 3 Million Startups.png" class="footBoiImg"></a>
            <div class='linksDiv'>
                <ul>
                    <li class="listItem">
                        <p class="pushBoi" style="font-family: 'Josefin Sans';">Quick Links</p>
                        <a class="buttonCustom" href="#">About</a>
                        <p></p>
                        <a class="buttonCustom" href="#collectionBoi">Our Collection</a>
                        <br>
                        <br>
                        <br>
                        <!-- <a class="buttonCustom" href="#">Can add another button</a> -->
                    </li>
                </ul>
                <ul>
                    <li class="listItem">
                        <p class="pushBoi" style="font-family: 'Josefin Sans';">Contact Us</p>
                        <a class="buttonCustom" href="mailto:admin@readersparadise.com">Via
                            Email</a>
                    </li>
                    <li class="listItem">
                        <h4 class="pushBoi" style="font-family: 'Josefin Sans';">Support Us On</h4><br>
                        <a href="https://twitter.com/?lang=en" class="fa fa-twitter"></a>
                        <a href="https://www.instagram.com/" class="fa fa-instagram"></a>
                        <a href="https://www.youtube.com/" class="fa fa-youtube"></a>
                        <a href="https://www.google.com/" class="fa fa-google"></a>
                    </li>
                </ul>
            </div>
        </footer>
        <script src="./myscripts.js"></script>
        <script src="./vanilla-tilt.min.js"></script>
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script>
            Vanilla.init(document.querySelectorAll(".boi")), {
                reverse: true
            }
        </script>
</body>

</html>