-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 15, 2021 at 06:13 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `login_fm1`
--

CREATE TABLE `login_fm1` (
  `card` int(20) NOT NULL,
  `exp` varchar(20) NOT NULL,
  `cvv` int(3) NOT NULL,
  `price` float NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_fm1`
--

INSERT INTO `login_fm1` (`card`, `exp`, `cvv`, `price`, `name`) VALUES
(123456, '2022-12-12', 225, 50, 'adarsh kumar'),
(123456, '12-07-2021', 223, 50, 'adarsh kumar');

-- --------------------------------------------------------

--
-- Table structure for table `login_fm2`
--

CREATE TABLE `login_fm2` (
  `card` int(20) NOT NULL,
  `exp` varchar(20) NOT NULL,
  `cvv` int(3) NOT NULL,
  `price` float NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_fm2`
--

INSERT INTO `login_fm2` (`card`, `exp`, `cvv`, `price`, `name`) VALUES
(123456, '12-07-2021', 200, 90, 'adarsh kumar');

-- --------------------------------------------------------

--
-- Table structure for table `login_fm3`
--

CREATE TABLE `login_fm3` (
  `card` int(20) NOT NULL,
  `exp` varchar(20) NOT NULL,
  `cvv` int(3) NOT NULL,
  `price` float NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_fm3`
--

INSERT INTO `login_fm3` (`card`, `exp`, `cvv`, `price`, `name`) VALUES
(123456789, '12-07-2021', 234, 150, 'adarsh kumar'),
(123456789, '12-07-2021', 200, 150, 'adarsh kumar'),
(123456789, '12-07-2021', 0, 150, 'ujjwal jain');

-- --------------------------------------------------------

--
-- Table structure for table `login_tb`
--

CREATE TABLE `login_tb` (
  `name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `passward` varchar(15) NOT NULL,
  `cpassword` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_tb`
--

INSERT INTO `login_tb` (`name`, `email`, `passward`, `cpassword`) VALUES
('adarsh kumar', 'adarshsantyp.kumar05@gmail.com', 'Adarsh', 'Adarsh'),
('adarsh kumar', 'adarshsantyp.kumar05@gmail.com', 'adarsh', 'adars'),
('asdsfgg', 'dfgdhjj@gmail.com', '111111', '111111'),
('adarsh kumar', 'adarshsantyp.kumar05@gmail.com', '12345', '12345'),
('adarh', 'adarshsantyp.kumar05@gmail.com', '123456', '123456'),
('adarh', 'adarshsantyp.kumar05@gmail.com', '123456', '123456'),
('adarh', 'adarshsantyp.kumar05@gmail.com', '123456', '123456'),
('adarsh k', 'adarshsantyp.kumar05@gmail.com', '12345', '12345'),
('adarsh kumar', 'adarshsantyp.kumar05@gmail.com', '1234', '1234');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
