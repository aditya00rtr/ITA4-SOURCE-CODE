<?php
 echo "Wait please"; 
$servername = "localhost";
$username = "root";
$password = "";
$database_name="courses";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$database_name);


// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
if(isset($_POST['save']))
{
    $firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $course=$_POST['course'];
    $gender=$_POST['gender'];
    $country_code=$_POST['country_code'];
    $phone=$_POST['phone'];
    $email=$_POST['email'];
   
    

    $sql_query = "insert into registration
    ( firstname, lastname, course, gender, country_code, phone,  email)
    values
    ('$firstname' , '$lastname' , '$course' , '$gender' , '$country_code' , '$phone' , '$email'  )";
    if(mysqli_query($conn,$sql_query))
      {
       
       
        header("location: project.html");
        

    }
    else{
        echo"error:" . mysqli_error($conn) ;
        

    }
    mysqli_close($conn);


}
?>