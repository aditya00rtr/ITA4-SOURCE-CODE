<?php
 echo "Wait please"; 
$servername = "localhost";
$username = "root";
$password = "";
$database_name="courses";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$database_name);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
if(isset($_POST['save']))
{
    $firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $mailid=$_POST['mailid'];
    $subject=$_POST['subject'];
    
    

    $sql_query = "insert into feedback
    ( firstname, lastname, mailid, subject)
    values
    ('$firstname' , '$lastname' , '$mailid' , '$subject')";
    if(mysqli_query($conn,$sql_query))
    {
        header("location: Project.html");

    }
    else{
        echo"error:" . mysqli_error($conn) ;

    }
    mysqli_close($conn);


}
?>