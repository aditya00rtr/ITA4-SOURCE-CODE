<?php
 echo "Wait please"; 
$servername = "localhost";
$username = "root";
$password = "";
$database_name="courses";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$database_name);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
if(isset($_POST['save']))
{
    $account=$_POST['acc'];
    $name=$_POST['name'];
    $date=$_POST['date'];
    $password=$_POST['password'];
    $amount=$_POST['amount'];
   
    

    $sql_query = "insert into pay
    (account,Name,date,password,amount)
    values
    ('$account' ,'$name', '$date' , '$password' , '$amount' )";
    if(mysqli_query($conn,$sql_query))
    {
        header("location: project.html");

    }
    else{
        echo"error:" . mysqli_error($conn) ;

    }
    mysqli_close($conn);


}
?>