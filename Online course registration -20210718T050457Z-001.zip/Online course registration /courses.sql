-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 14, 2021 at 05:59 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `courses`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `mailid` varchar(30) NOT NULL,
  `subject` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`firstname`, `lastname`, `mailid`, `subject`) VALUES
('ABHISHEK', 'KOUNDAL', 'abhikoundal4122001@gmail.com', 'awdawdw dwaw adw dawd'),
('atanu', 'yup', 'abhikoundal4122001@gmail.com', 'awdasdafFafafafawdawdadw adaw dadawdawdaw dwd a dawdadada');

-- --------------------------------------------------------

--
-- Table structure for table `pay`
--

CREATE TABLE `pay` (
  `account` varchar(10) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `password` varchar(10) NOT NULL,
  `amount` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pay`
--

INSERT INTO `pay` (`account`, `Name`, `date`, `password`, `amount`) VALUES
('123', '', '2021-07-22', '333', '99'),
('123', '', '2021-07-15', 'adawd', '99'),
('3334444333', '', '2021-07-27', 'asdfgh', '99'),
('3334444333', 'ABHISHEK KOUNDAL', '2021-07-21', 'asdf', '99');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `course` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `country_code` varchar(3) NOT NULL,
  `phone` int(20) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`firstname`, `lastname`, `course`, `gender`, `country_code`, `phone`, `email`) VALUES
('ABHISHEK', 'KOUNDAL', 'CDS', 'Male', '268', 1045, 'abhikoundal4122001@gmail.com'),
('ABHISHEK', 'KOUNDAL', 'CDS', 'Male', '268', 1045, 'abhikoundal4122001@gmail.com'),
('', '', '', '', '', 0, ''),
('', '', '', '', '', 0, ''),
('', '', '', '', '', 0, ''),
('ABHISHEK', 'KOUNDAL', 'SSC CHSL', 'Male', '268', 2147483647, 'abhikoundal4122001@gmail.com'),
('atanu', 'asd', 'IBPS PO', 'Male', '123', 1231232, 'shinchan9211420@gmail.com'),
('atanu', 'asd', 'IBPS PO', 'Male', '123', 1231232, 'shinchan9211420@gmail.com'),
('ad', 'ddawd', 'f-LIC AAO', 'Other', '123', 1231232, 'shinchan9211420@gmail.com'),
('ABHISHEK', 'KOUNDAL', 'F-LIC AAO', 'Male', '268', 2147483647, 'abhikoundal4122001@gmail.com'),
('asd', 'asd', 'F-SBI clerk', 'Male', '123', 2147483647, 'shinchan9211420@gmail.com'),
('ABHISHEK', 'KOUNDAL', 'Gk-CDS', 'Male', '268', 2147483647, 'abhikoundal4122001@gmail.com'),
('ABHISHEK', 'KOUNDAL', 'Gk-CDS', 'Male', '268', 2147483647, 'abhikoundal4122001@gmail.com'),
('rahul', 'kumar ', ' Select  the Courses ', 'Male', '+91', 2147483647, 'awda'),
('rahul2', 'adas', 'F-LIC AAO', 'Male', '+91', 123456789, 'asdasda');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
