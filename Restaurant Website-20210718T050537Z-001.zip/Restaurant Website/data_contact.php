<?php
	$full_name = $_POST['full_name'];
	$message = $_POST['message'];
	$email = $_POST['email'];

	// Database connection
	$conn = new mysqli('localhost','root','','restaurant');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into contact(full_name, email, message) values(?, ?, ?)");
		$stmt->bind_param("sss", $full_name, $email, $message);
		$execval = $stmt->execute();
		echo $execval;
		echo "Your Request Has Been Submitted Successfully.";
		$stmt->close();
		$conn->close();
	}
?>