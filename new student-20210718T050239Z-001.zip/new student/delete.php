<!DOCTYPE html>
<html>
    <style>
        body{
            font-size: 40px;
            font-family: sans-serif;
            background-image: url('delete.jpeg');
            background-size: cover;
            height: 100vh;
            position: relative;
            background-repeat: no-repeat;
            color: white;
        }
        p{
            position:absolute;
            left:100px;  
            top: 260px;
        }
        a{
            top:500px;
            text-decoration: none;
            position: absolute;
            font-size: 30px;
            font-weight:20px;
            border: 1px;
            border-color:blue;
            background-color: lightblue;
            height: 35px;
            width:  200px;
            text-align: center;
            border-radius:4px;
            left:600px;
        }
   
    </style>
 <body>
    <?php
    error_reporting(0);
        $delete = $_POST['delete'];

        $conn = mysqli_connect('localhost','root','','sturegistration');
        if(!$conn){
            echo "Failed to connect to the server";
        }
        $delete = "delete  from registration where id = '$delete';";
        $sql = mysqli_query($conn,$delete);
        if($sql){
            echo  "<p>Registration has been deleted.
            <br>We are so sad that you have left. We wish<br> you all the best where you will be heading.</p>";
        }
        else{
            echo  "<p>An error occured while deleting your registration.</p> ";
        }
    ?> 


    <a href="onlineregistration.html">Back to home</a>   
       
</body>
</html>       

        
