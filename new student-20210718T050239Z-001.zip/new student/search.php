<!DOCTYPE html>
<html>
<style>
        body{
            font-size: 22px;
            font-family: sans-serif;
            background-image: url('search.jpeg');
            background-size: cover;
            height: 100vh;
            position: relative;
            background-repeat: no-repeat;
            color: white;
            text-align:100px;
        }
        table{
            position:absolute;
            left:100px;
            top:380px
        }
        p{
            position:absolute;
            left:100px;  
            top: 260px;
        }
        .no_data{
            position:absolute;
            left:100px;  
            top: 260px;
            font-size: 25px;
        }

        a{
            top:220px;
            text-decoration: none;
            position: absolute;
            font-size: 30px;
            font-weight:20px;
            border: 1px;
            border-color:blue;
            background-color: lightblue;
            height: 35px;
            width:  200px;
            text-align: center;
            border-radius:4px;
            left:500px;
        }
    

    </style>
<head>
    <title>Document</title>
   
</head>
<body>

        
<?php
    error_reporting(0);
    $search = $_POST['search'];
    $conn = mysqli_connect('localhost','root','','sturegistration');
    if(!$conn){
        echo "Failed to connect to the server";
    }

    if(isset($search)){
        $id = $_POST['id'];
        $check = "select * from registration where id = '$id';";
        $check_run = mysqli_query($conn,$check);

        
 
        if($row = mysqli_fetch_array($check_run))
        { 
           ?> <p>
              <?php echo "Dear";?>
             <?php echo "<br>";?>
             <?php echo $row['fname'];?>
             <?php echo " ";?>
             <?php echo $row['lname'];?>
             <?php echo " ! <br> Your registered with ID No." ; echo $row['id'];?>
            </p>
            
            <table border = "2">
                <tr>
                    <th>Reg. number</th>
                    <th>First name</th>
                    <th>Last name</th>
                    <th>Email</th>
                    <th>DoB</th>
                    <th>Gender</th>
                    <th>Course</th>
                    <th>Nationality</th>
                    <th>Mobile Number</th>

                </tr>
                <tr>
                    <td><?php echo $row['id'];?></td>
                    <td><?php echo $row['fname'];?></td>
                    <td><?php echo $row['lname'];?></td>
                    <td><?php echo $row['email'];?></td>
                    <td><?php echo $row['dob'];?></td>
                    <td><?php echo $row['gender'];?></td>
                    <td><?php echo $row['course'];?></td>
                    <td><?php echo $row['nationality'];?></td>
                    <td><?php echo $row['mobile'];?></td>

                </tr>
            </table>    
            <?php
        }
        else//(!mysqli_fetch_array($check_run))
        { echo "<p >Sorry,<br> it seems you have not yet registered with us.<br> We were unable to to locate your data.</p>";
        
        }
    }
   ?>
   <p> <a href="onlineregistration.html">Back to home</a> </p>
 </body>
</html>