<!DOCTYPE html>
<html lang="en">
    <style>
        body{
            background-image: url('login.jpeg');
            background-size: cover;
            height: 100vh;
            position: relative;
            
        }
        .info{
            position: absolute;
            border-width: 10px;
            top: 30%;
            left: 35%;
            color: white;
            font-size: large;
            font-weight: bolder;
            font-family: sans-serif;
        }
        input{
            width: 400px;
            height: 30px;
            border-width: 1px;
            border-color: rgb(201, 196, 196);
            border-radius: 20px;
            background-color:rgba(15, 13, 13,0.3);
            color: white;
            }
        .submit{
            width: 400px;
            height: 30px;
            border-width: 0px;
            border-radius: 20px;
            background-color:rgb(202, 54, 54);
            color: white; 
            font-size: large;
            transition: 1s;
        }    
        .submit:hover{
            transform: scale(1.1);
            width: 400px;
            height: 30px;
            border-width: 0px;
            border-radius: 20px;
            background-color:rgb(202, 54, 54);
            color: white; 
            font-size: large;
        }  
        p{
            color: white;
            left:44%;
            position: absolute;
            top: 70%;
            font-weight: bolder;
            font-family: sans-serif;
            font-size:15px;
            
        }  
        a{
            position: absolute;
            top:75%;
            left: 35%;
            font-size: large;
            font-weight: bolder;
            font-family: sans-serif;
            color: white;
        }
    </style>
<head>
    <title>Document</title>
</head>
<body>
    <div class="info">
        <h1>Andsan University</h1>
        Welcome to the University Information Management <br> System
    
    <form action="login.php" method="POST" autocomplete = "off">
        <input type="number" name="regno" placeholder="Registration Number"   required> <br> <br>
        <input type="password" name="upass" placeholder="Password" required autocomplete = "off" > <br> <br> <br>
        <input class="submit" type="submit" name="submit" value="log in">
    </form>
</div>
<?php
    error_reporting(0);
    $regno = $_POST['regno'];
    $upass = $_POST['upass'];
    $conn = mysqli_connect('localhost','root','','sturegistration');
    if(!$conn){
        echo "Failed to connect to the server";
    }

    if(isset($_POST['submit'])){
        $check = "select * from registration where id = '$regno';";
        $check_run = mysqli_query($conn,$check);

        
 
        if($row = mysqli_fetch_array($check_run))
        { 
         if($upass == ""){
            ?>
            <p style ="color: orange ; text-shadow:0 0 15px rgb(209, 180, 12);">Password reqiured.</p><?php 
            
           

         }
         else if($upass != $row['password']){
             ?>
             <p style ="color:red;text-shadow:0 0 15px rgb(225, 0, 0);">Incorrect Password.</p><?php
            
         }


         else if($regno == $row['id'] && $upass == $row['password']){
           ?>
           <p style ="color: rgb(0,255,65); text-shadow:0 0 15px rgb(60, 172, 16); ">login was succesfull.</p><?php
             }
            
        }
    }?>   
      <a href="onlineregistration.html">Back home</a>
         
</body>
</html>