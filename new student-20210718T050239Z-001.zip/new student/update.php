
<!DOCTYPE html>
<html>
    <style>
      body{
            font-size: 60px;
            font-family: sans-serif;
            text-align: center ;
            top:300px;
            background-image: url('update.jpeg');
            background-size: cover;
            height: 100vh;
            position: relative;
            background-repeat: no-repeat;
            color: white;
        }
        a{
            top:150px;
            text-decoration: none;
            position: absolute;
            font-size: 30px;
            font-weight:20px;
            border: 1px;
            border-color:blue;
            background-color: lightblue;
            height: 35px;
            width:  200px;
            text-align: center;
            border-radius:4px;
            left:650px;
        }
   
    </style>
 <body>
       <?php
       error_reporting(0);
        $to = $_POST['to'];
        $uid = $_POST['uid'];
        $updated = $_POST['updated'];
        $conn = mysqli_connect('localhost','root','','sturegistration');
        if(!$conn){
        echo "Failed to connect to the server";
        }
        $update = "update registration set $updated = '$to' where id = '$uid' ;";
        $sql = mysqli_query($conn,$update);

        if($sql){
            echo "Updates have taken place successfully !";}

         else{
             echo "Error in updating<br> try to refresh the page" ;
            
         }        
         ?>
         <p> <a href="onlineregistration.html">Back to home</a> </p>        
    </body>
 </html>