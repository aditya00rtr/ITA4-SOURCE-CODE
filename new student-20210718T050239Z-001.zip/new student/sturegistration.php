<!DOCTYPE html>
<html>
    <style>
        body{
            font-size: 40px;
            font-family: sans-serif;
            background-image: url('result.jpeg');
            background-size: cover;
            height: 100vh;
            position: relative;
            background-repeat: no-repeat;
            color: white;
        }
        p{
            position:absolute;
            left:100px;  
            top: 260px;
        }
        a{
            top:500px;
            text-decoration: none;
            position: absolute;
            font-size: 30px;
            font-weight:20px;
            border: 1px;
            border-color:blue;
            background-color: lightblue;
            height: 35px;
            width:  200px;
            text-align: center;
            border-radius:4px;
            left:600px;
        }
   
    </style>
 <body>
<?php
        error_reporting(0);
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $email = $_POST['email'];
        $mobile = $_POST['mobile'];
        $nationality = $_POST['nationality'];
        $dob = $_POST['dob'];
        $course = $_POST['course'];
        $gender = $_POST['gender'];
        $file = $_POST['file'];
        $password = $_POST['password'];

              $conn = mysqli_connect('localhost','root','','sturegistration');
              $insert = "insert into registration(fname,lname,email,mobile,nationality,dob,course,gender,file,password) 
             values('$fname','$lname','$email','$mobile','$nationality','$dob','$course','$gender','$file','$password')";

            if(!$conn){
                echo "Failed to connect to the server";
            }
       
             $sql = mysqli_query($conn,$insert);
         
            if($sql){
                echo "<p>Congratulations ! <br> your registration has been successfull <br>Your
                       registration number is :- ". $conn->insert_id ?></p><?php ;
                   }

            else{
                 echo "Something went wrong, ensure all the data is filled correctly and try again";
                }   
                    
?>
     <a href="onlineregistration.html">Back to home</a>         
 </body>
</html>

