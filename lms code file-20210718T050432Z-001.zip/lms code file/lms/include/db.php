<?php
$con = mysqli_connect('localhost','root','','lms');
$bal = "ffffffff";
?>