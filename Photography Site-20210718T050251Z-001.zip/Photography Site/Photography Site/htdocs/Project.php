<?php
$servername="localhost";
$username="root";
$password="";
$database_name="project";

$conn=mysqli_connect($servername,$username,$password,$database_name);
//now check the connection

if(!$conn)
{
    die('Connect Error('.mysqli_connect_errno().')'.mysqli_connect_error());
}
if(isset($_POST['Message']) && isset($_POST['firstname']))
{
    $Firstname=$_POST['firstname'];
    $Lastname=$_POST['lastname'];
    $Email=$_POST['email'];
    $Subject=$_POST['subject'];
    $Message=$_POST['Message'];

    $sql_query="INSERT  INTO contact 
    VALUES('$Firstname','$Lastname','$Email','$Subject','$Message')";

    if(mysqli_query($conn,$sql_query))
    {
        echo "New Details Entry inserted successfully!";
    }
    else{
        echo"Error:".$sql."".mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>