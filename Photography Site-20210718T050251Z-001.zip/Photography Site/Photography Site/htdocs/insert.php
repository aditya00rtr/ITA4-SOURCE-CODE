<?php
$servername="localhost";
$username="root";
$password="";
$database_name="project";

$conn=mysqli_connect($servername,$username,$password,$database_name);
//now check the connection

if(!$conn)
{
    die('Connect Error('.mysqli_connect_errno().')'.mysqli_connect_error());
}
if(isset($_POST['Comment']) && isset($_POST['Name']) && isset($_POST['Email']) &&isset($_POST['Comment']))
{
    $Name=$_POST['Name'];
    $Email=$_POST['Email'];
    $Comment=$_POST['Comment'];

    $sql_query="INSERT  INTO comment 
    VALUES('$Name','$Email','$Comment')";

    if(mysqli_query($conn,$sql_query))
    {
        echo "New Comment inserted successfully!";
    }
    else{
        echo"Error:".$sql."".mysqli_error($conn);
     }
     mysqli_close($conn);
}